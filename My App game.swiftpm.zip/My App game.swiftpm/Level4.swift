import SwiftUI
import AVFoundation

// Helper function for debug logging
func debugLog(_ message: String) {
    #if DEBUG
    print("Debug: \(message)")
    #endif
}

struct Level4: View {
    @EnvironmentObject private var levelManager: LevelManager 
    
    private var deathNotes: [(note: String, position: CGPoint, rotation: Double)] {
        levelManager.getDeathNotes(for: 4)
    }
    
    private let platform4Size: CGSize = CGSize(width: 1200, height: 50)   
    private let platform4Position: CGPoint = CGPoint(x: 600, y: 550)       
    
    private let coffee1Size: CGSize = CGSize(width: 22, height: 35)
    private let coffee1Position: CGPoint = CGPoint(x: 780, y: 500)
    
    private let coffee2Size: CGSize = CGSize(width: 22, height: 35)
    private let coffee2Position: CGPoint = CGPoint(x: 860, y: 500)
    
    private let coffee3Size: CGSize = CGSize(width: 22, height: 35)
    private let coffee3Position: CGPoint = CGPoint(x: 940, y: 500)
    
    @State private var playerState: PlayerState = .idle
    @State private var playerFacingRight = false  
    @State private var playerPosition = CGPoint(x: 1100, y: 300)      
    @State private var playerVelocity = CGPoint.zero
    @State private var isOnGround = true
    @State private var isMovingLeft = false
    @State private var isMovingRight = false
    
    @State private var walkFrame = 1
    @State private var lastAnimationTime = Date()
    private let animationInterval: TimeInterval = 0.08
    
    private let gravity: CGFloat = 0.8
    private let jumpForce: CGFloat = -15
    private let moveSpeed: CGFloat = 7
    let physicsTimer = Timer.publish(every: 1/60, on: .main, in: .common).autoconnect()
    
    @State private var swappedControls = false
    @State private var showSwappedMessage = false
    
    private let rejected1Size: CGSize = CGSize(width: 210, height: 100)
    private let rejected1Start: CGPoint = CGPoint(x: 250, y: 400)
    private let rejected1Speed: CGFloat = 9.0
    private let rejected1MaxTop: CGFloat = 200
    private let rejected1MaxBottom: CGFloat = 650
    private let rejected1Rotation: Angle = .degrees(90)
    
    private let rejected2Size: CGSize = CGSize(width: 210, height: 100)
    private let rejected2Start: CGPoint = CGPoint(x: 450, y: 400)
    private let rejected2Speed: CGFloat = 7.0
    private let rejected2MaxTop: CGFloat = 200
    private let rejected2MaxBottom: CGFloat = 650
    private let rejected2Rotation: Angle = .degrees(90)
    
    private let rejected3Size: CGSize = CGSize(width: 210, height: 100)
    private let rejected3Start: CGPoint = CGPoint(x: 650, y: 400)
    private let rejected3Speed: CGFloat = 5.0
    private let rejected3MaxTop: CGFloat = 200
    private let rejected3MaxBottom: CGFloat = 650
    private let rejected3Rotation: Angle = .degrees(90)
    
    @State private var rejected1Position: CGPoint
    @State private var rejected1MovingUp: Bool = true
    
    @State private var rejected2Position: CGPoint
    @State private var rejected2MovingUp: Bool = true
    
    @State private var rejected3Position: CGPoint
    @State private var rejected3MovingUp: Bool = true
    
    private let homeSize: CGSize = CGSize(width: 80, height: 80)   
    private let homePosition: CGPoint = CGPoint(x: 95, y: 480)      
    
    private let binSize: CGSize = CGSize(width: 80, height: 100)    
    
    @State private var homeVisible: Bool = true
    @State private var showBin: Bool = false
    @State private var binPosition: CGPoint
    
    @State private var isDead = false
    @State private var isLevelComplete = false
    
    @State private var isDarkMode = false
    @State private var showTorch = false
    @State private var torchPosition: CGPoint = .zero
    
    @State private var showGlowingText = false
    private let glowingText = "/Users/You/Documents/WhyAreYouStillPlaying/Home.app"
    
    private let glowingTextPosition = CGPoint(x: 580, y: 340) 
    
    @State private var showBSOD = false
    
    private let glowingTextSize = CGSize(width: 400, height: 40)  // Adjust based on text size
    
    @State private var showXButton = false
    @State private var showMessage = false
    
    private let typeClassifier: PlayerTypeClassifier? = try? PlayerTypeClassifier()
    private let frustrationModel: PlayerFrustration? = try? PlayerFrustration()
    @State private var predictionMessage: String? = nil
    @State private var currentLevelDeaths: Int = 0
    @State private var hesitationCount: Int = 0
    @State private var totalTimeSpent: TimeInterval = 0
    @State private var levelStartTime = Date()
    
    @State private var showTrollMessage = false
    
    @State private var timesFooled: Int = 0
    
    @State private var rollingOffset: CGFloat = UIScreen.main.bounds.height
    
    @State private var hasBeenFooledBy: Set<String> = []
    
    // Add hesitation zone configuration
    private let hesitationZones: [CGRect] = [
        CGRect(x: 900, y: 405, width: 130, height: 120),  // Before coffee3
        CGRect(x: 700, y: 405, width: 100, height: 120),   // Before obstacle3
        CGRect(x: 500, y: 405, width: 100, height: 120),   // Before obstacle2
        CGRect(x: 300, y: 405, width: 100, height: 120)    // Before obstacle1
    ]
    @State private var isInHesitationZone = false
    @State private var hesitationStartTime: Date?
    private let hesitationThreshold: TimeInterval = 1.0
    
    @State private var showObstacles = true

    @State private var startingDeathCount: Int = 0

    // Update deathCount computed property to include all deaths from previous levels
    private var deathCount: Int {
        levelManager.getTotalDeathCount()  // Get total deaths across all levels
    }

    @State private var coffeeCollected: [Bool] = [false, false, false]  // Track 3 coffees

    @State private var showCredits = false
    @State private var fadeTextIndex = 0
    @State private var showFadeText = false
    @State private var showRollingCredits = false

    private let fadeTexts: [[String]] = [
        [
            "Thank you for playing!",
            "(And suffering)"
        ],
        [
            "**Official Submission for Apple Swift Student Challenge 2025**",
            "Built with SwiftUI, SpriteKit, Core ML, and pure chaos"
        ],
        [
            "Game Version: 1.0 (Final Final Version)",
            "Development Time: 3 weeks and sleepless nights",
            "Energy Source: Coffee",
            "Debugging Tool: Print statements and sheer willpower"
        ]
    ]

    private let credits = [
        "---- CREDITS ----",
        "",
        "Created By:",
        "Dhruv Goswami",
        "(A.K.A. The Developer who should have stopped at Level1.swift)",
        "",
        "",
        "Game Development Team:",
        "Just Me",
        "My MacBook Air",
        "That one bug that still exists somewhere",
        "",
        "",
        "Art and Design:",
        "Me again",
        "My iPad Pro",
        "I'm not an artist, still tried my best studio",
        "",
        "",         
        "Music and Sound Effects:",
        "Random noises I found online",
        "My Mechanical Keyboard",
        "That one sound I regret adding",
        "Silence (Actually the best part of the game)",
        "",
        "",
        "ML Insights Team:",
        "A Bunch of Overconfident Algorithms",
        "Create ML and its best models",
        "",
        "",
        "🏆",
        "Achievement Unlocked:",
        "Damn you actually finished the game!",
        "",
        "",
        "------ THE END ------",
        "",
        "",
        ""
    ]

    @State private var audioPlayer: AVAudioPlayer?

    private let invisibleWallConfig = (
        position: CGPoint(x: 1170, y: 420),
        size: CGSize(width: 20, height: 490)
    )

    init() {
        _rejected1Position = State(initialValue: rejected1Start)
        _rejected2Position = State(initialValue: rejected2Start)
        _rejected3Position = State(initialValue: rejected3Start)
        // Initialize binPosition at the bottom of platform4
        let platform4Bottom = platform4Position.y + platform4Size.height/2
        _binPosition = State(initialValue: CGPoint(x: homePosition.x, y: platform4Bottom))
    }

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Add white background as the base layer
                Color.white
                    .ignoresSafeArea()
                    .zIndex(0)
                
                ForEach(deathNotes.indices, id: \.self) { index in
                    Image(deathNotes[index].note)
                        .resizable()
                        .frame(width: 150, height: 150)
                        .position(deathNotes[index].position)
                        .rotationEffect(.degrees(deathNotes[index].rotation))
                        .opacity(0.7)  
                        .shadow(color: .black.opacity(0.1), radius: 5, x: 2, y: 2)
                        .zIndex(0.1)  // Keep consistently behind all game elements
                        .allowsHitTesting(false)
                }
                
                // Platform (z-index: 1)
                Image("platform4")
                    .resizable()
                    .frame(width: platform4Size.width, height: platform4Size.height)
                    .position(platform4Position)
                    .zIndex(1)
                
                // Death Counter overlay
                Text("Deaths: \(deathCount)")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.red)
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color.black.opacity(0.7))
                    )
                    .position(x: geometry.size.width / 2, y: 50)
                    .zIndex(3)
                
                Image("platform4")
                    .resizable()
                    .frame(width: platform4Size.width, height: platform4Size.height)
                    .position(platform4Position)
                
                ForEach(hesitationZones.indices, id: \.self) { index in
                    Rectangle()
                        .fill(Color.clear)
                        .opacity(0.7)
                        .frame(width: hesitationZones[index].width, 
                               height: hesitationZones[index].height)
                        .position(x: hesitationZones[index].midX, 
                                  y: hesitationZones[index].midY)
                        .zIndex(0.1)
                }
                
                if !isDarkMode && showObstacles { 
                    // Show regular game elements
                    Group {
                        // Coffee assets
                        Image("coffee")
                            .resizable()
                            .frame(width: coffee1Size.width, height: coffee1Size.height)
                            .position(coffee1Position)
                            .opacity(coffeeCollected[0] ? 0 : 1)
                            .zIndex(3)
                        Image("coffee")
                            .resizable()
                            .frame(width: coffee2Size.width, height: coffee2Size.height)
                            .position(coffee2Position)
                            .opacity(coffeeCollected[1] ? 0 : 1)
                            .zIndex(3)
                        Image("coffee")
                            .resizable()
                            .frame(width: coffee3Size.width, height: coffee3Size.height)
                            .position(coffee3Position)
                            .opacity(coffeeCollected[2] ? 0 : 1)
                            .zIndex(3)
                        
                        // Rejected assets
                        Image("rejected")
                            .resizable()
                            .frame(width: rejected1Size.width, height: rejected1Size.height)
                            .rotationEffect(rejected1Rotation)
                            .position(rejected1Position)
                            .zIndex(2)
                        Image("rejected")
                            .resizable()
                            .frame(width: rejected2Size.width, height: rejected2Size.height)
                            .rotationEffect(rejected2Rotation)
                            .position(rejected2Position)
                            .zIndex(2)
                        Image("rejected")
                            .resizable()
                            .frame(width: rejected3Size.width, height: rejected3Size.height)
                            .rotationEffect(rejected3Rotation)
                            .position(rejected3Position)
                            .zIndex(2)
                    }
                }
                
                if homeVisible {
                    Image("Home")
                        .resizable()
                        .frame(width: homeSize.width, height: homeSize.height)
                        .position(homePosition)
                }
                
                // Display and animate Bin from assets when triggered.
                if showBin {
                    Image("bin")
                        .resizable()
                        .frame(width: binSize.width, height: binSize.height)
                        .position(binPosition)
                }
                
                Player(currentState: playerState, facingRight: playerFacingRight, walkFrame: walkFrame)
                    .position(playerPosition)
                    .zIndex(4)
                    .onReceive(physicsTimer) { _ in
                        updatePhysics(in: geometry)
                        updatePlayerState()
                        updateAnimation()
                        updateRejected() 
                        if isDarkMode {
                            torchPosition = playerPosition
                        }
                    }
                
                // Add player collision box visualization
                Rectangle()
                    .stroke(Color.clear, lineWidth: 2)
                    .fill(Color.clear.opacity(0.2))
                    .frame(width: 50, height: 70) // Match the collision box size used in physics
                    .position(playerPosition)
                    .zIndex(0.5)

                // Display swapped message overlay when active.
                if showSwappedMessage {
                    Text("Left is the new right")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.blue)
                        .padding(8)
                        .background(Color.white.opacity(0.8))
                        .cornerRadius(8)
                        .zIndex(4)
                }
                
                Controls(
                    leftConfig: ControlConfig(
                        size: 100,
                        position: CGPoint(x: 100, y: geometry.size.height - 80),
                        opacity: 0.8
                    ),
                    jumpConfig: ControlConfig(
                        size: 100,
                        position: CGPoint(x: geometry.size.width - 100, y: geometry.size.height - 80),
                        opacity: 0.8
                    ),
                    rightConfig: ControlConfig(
                        size: 100,
                        position: CGPoint(x: 250, y: geometry.size.height - 80),
                        opacity: 0.8
                    ),
                    onLeftBegan: {
                        if swappedControls {
                            // Left behaves as right.
                            isMovingRight = true
                            playerState = .walking
                            playerFacingRight = true
                        } else {
                            isMovingLeft = true
                            playerState = .walking
                            playerFacingRight = false
                        }
                    },
                    onLeftEnded: {
                        if swappedControls {
                            isMovingRight = false
                            if !isMovingLeft { playerState = .idle }
                        } else {
                            isMovingLeft = false
                            if !isMovingRight { playerState = .idle }
                        }
                    },
                    onRightBegan: {
                        if swappedControls {
                            // Right behaves as left.
                            isMovingLeft = true
                            playerState = .walking
                            playerFacingRight = false
                        } else {
                            isMovingRight = true
                            playerState = .walking
                            playerFacingRight = true
                        }
                    },
                    onRightEnded: {
                        if swappedControls {
                            isMovingLeft = false
                            if !isMovingRight { playerState = .idle }
                        } else {
                            isMovingRight = false
                            if !isMovingLeft { playerState = .idle }
                        }
                    },
                    onJumpBegan: {
                        if isOnGround {
                            playerVelocity.y = jumpForce
                            isOnGround = false
                            playerState = .jumping
                        }
                    },
                    onJumpEnded: { }
                )
                .zIndex(3)
                
                if isDead {
                    Color.black.opacity(0.8)
                        .ignoresSafeArea()
                        .zIndex(4)
                    
                    Image("youDied")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400) 
                        .padding()
                        .zIndex(4)
                        .onAppear {
                            playDeathSound() 
                            // Automatically clear death overlay after 2 seconds
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                                isDead = false
                            }
                        }
                }
                
                if isLevelComplete {
                    Color.black.opacity(0.8)
                        .ignoresSafeArea()
                        .zIndex(4)
                    VStack(spacing: 20) {
                        if let msg = predictionMessage {
                            Text(msg)
                                .font(.system(size: 28, weight: .bold))
                                .foregroundColor(.white)
                                .padding()
                        } else {
                            Text("Calculating your player style...")
                                .font(.system(size: 24, weight: .regular))
                                .foregroundColor(.white)
                                .padding()
                        }
                        Button("Continue") {
                            withAnimation {
                                showBSOD = true // Show BSOD instead of direct transition
                            }
                        }
                        .font(.system(size: 24, weight: .bold))
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    .zIndex(4)
                }
                
                Button("Back to Map") {
                    withAnimation {
                        levelManager.currentState = .progressMap
                    }
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
                .position(x: 100, y: 50)
                .zIndex(3)
                
                // Dark overlay with torch effect and glowing text
                if isDarkMode {
                    ZStack {
                        Canvas { context, size in
                            // Draw dark background
                            context.fill(
                                Path(CGRect(origin: .zero, size: size)),
                                with: .color(.black)
                            )
                            
                            // Create torch effect
                            let torchRadius: CGFloat = 100
                            let circle = Path(ellipseIn: CGRect(
                                x: torchPosition.x - torchRadius,
                                y: torchPosition.y - torchRadius,
                                width: torchRadius * 2,
                                height: torchRadius * 2
                            ))
                            
                            context.blendMode = .destinationOut
                            
                            // Use CGFloat instead of Float for the torch effect
                            context.drawLayer { ctx in
                                for radius in stride(from: CGFloat(0), to: torchRadius, by: CGFloat(1)) {
                                    let alpha = 1 - (radius / torchRadius)
                                    ctx.opacity = alpha
                                    
                                    let currentRadius = torchRadius - radius
                                    let circlePath = Path(ellipseIn: CGRect(
                                        x: torchPosition.x - currentRadius,
                                        y: torchPosition.y - currentRadius,
                                        width: currentRadius * 2,
                                        height: currentRadius * 2
                                    ))
                                    
                                    ctx.fill(circlePath, with: .color(.white))
                                }
                            }
                        }
                        
                        // Add glowing text when dark mode is active
                        if showGlowingText {
                            Text(glowingText)
                                .font(.system(size: 24, weight: .bold, design: .monospaced))
                                .foregroundColor(.green)
                                .shadow(color: .green, radius: 10, x: 0, y: 0)
                                .shadow(color: .green, radius: 20, x: 0, y: 0)
                                .transition(.opacity)
                                .position(glowingTextPosition)  
                        }
                    }
                    .allowsHitTesting(false)
                    .zIndex(2000)
                }
                
                // BSOD overlay with adjusted position
                if showBSOD {
                    ZStack {
                        Image("bsod")
                            .resizable()
                            .scaledToFill()
                            .ignoresSafeArea()
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .offset(x: -50)
                        
                        // Rest of BSOD overlay content
                        if showXButton {
                            Button(action: {
                                withAnimation {
                                    showTrollMessage = true
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                        showTrollMessage = false
                                    }
                                }
                            }) {
                                Image(systemName: "xmark.circle.fill")
                                    .font(.system(size: 30))
                                    .foregroundColor(.white)
                            }
                            .position(x: geometry.size.width - 70, y: 50) 
                        }
                        
                        // Troll message overlay
                        if showTrollMessage {
                            Text("Nice try, wait for machine to troll you")
                                .font(.system(size: 24, weight: .bold))
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.black.opacity(0.8))
                                .cornerRadius(10)
                                .position(x: geometry.size.width/2, y: geometry.size.height/2)
                        }
                    }
                    .zIndex(3000)
                    .onAppear {
                        // Show X button after 1 second
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                            withAnimation(.easeIn(duration: 0.3)) {
                                showXButton = true
                            }
                        }
                        
                        // Calculate ML insights and transition after BSOD
                        DispatchQueue.main.asyncAfter(deadline: .now() + 4.0) {
                            withAnimation {
                                showBSOD = false
                                totalTimeSpent = Date().timeIntervalSince(levelStartTime)
                                
                                // Calculate ML insights
                                predictionMessage = MLInsights.getPredictionMessage(
                                    level: 4,
                                    totalDeaths: deathCount,
                                    levelDeaths: currentLevelDeaths,
                                    hesitationCount: hesitationCount,
                                    timeSpent: totalTimeSpent,
                                    internalErrors: nil,
                                    timesFooled: timesFooled,
                                    playerTypeClassifier: typeClassifier,
                                    frustrationModel: frustrationModel
                                )
                            }
                        }
                    }
                }
                
                if !showBSOD && predictionMessage != nil {
                    Color.black.opacity(1.0)
                        .ignoresSafeArea()
                        .zIndex(3001)
                    
                    VStack(spacing: 20) {
                        Text(predictionMessage!)
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(.white)
                            .padding()
                        
                        Button("Roll Credits") {  
                            withAnimation {
                                showCredits = true
                            }
                        }
                        .font(.system(size: 24, weight: .bold))
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    .zIndex(3002)
                }

                // Credits overlay in the main ZStack after ML insights overlay:
                if showCredits {
                    Color.black
                        .ignoresSafeArea()
                        .zIndex(4000)
                    
                    // FADE-IN MESSAGES SEQUENCE
                    if !showRollingCredits {
                        VStack(spacing: 20) {
                            ForEach(fadeTexts[fadeTextIndex], id: \.self) { text in
                                Text(text)
                                    .font(.system(size: 32, weight: .bold, design: .monospaced))
                                    .foregroundColor(.white)
                                    .multilineTextAlignment(.center)
                            }
                        }
                        .opacity(showFadeText ? 1 : 0)
                        .animation(.easeInOut(duration: 1.0), value: showFadeText)
                        .onAppear {
                            showFadeText = true
                            advanceFadeSequence()
                        }
                        .zIndex(4001)
                    }
                    
                    if showRollingCredits {
                        VStack {
                            Spacer()
                            VStack(spacing: 12) {
                                ForEach(credits, id: \.self) { line in
                                    Text(line)
                                        .font(.system(size: 24, weight: .bold, design: .monospaced))
                                        .foregroundColor(.white)
                                        .multilineTextAlignment(.center)
                                }
                            }
                            .offset(y: rollingOffset)
                            .animation(.linear(duration: 20), value: rollingOffset)
                        }
                        .ignoresSafeArea()
                        .onAppear {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                withAnimation {
                                    rollingOffset = -UIScreen.main.bounds.height * 2
                                }
                                // Add fade to main menu after credits finish
                                DispatchQueue.main.asyncAfter(deadline: .now() + 20) { // Wait for credits to finish
                                    withAnimation(.easeOut(duration: 2.0)) {
                                        showCredits = false
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                            withAnimation {
                                                levelManager.currentState = .mainMenu
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        .zIndex(4001)
                    }
                }

                // Add in the ZStack body where other game elements are rendered
                Rectangle()
                    .fill(Color.clear) 
                    .frame(width: invisibleWallConfig.size.width, height: invisibleWallConfig.size.height)
                    .position(invisibleWallConfig.position)
                    .zIndex(1)
            }
        }
        .onAppear {
            startingDeathCount = levelManager.getTotalDeathCount()
            levelStartTime = Date()
            currentLevelDeaths = 0  // Reset level-specific death counter
            debugLog("Level 4 started - Initial death count: \(startingDeathCount)")
            
            // Import death notes from Level 3 with a staggered effect
            let level3Notes = levelManager.getDeathNotes(for: 3)
            
            // Import each note with a slight delay and random position adjustment
            for (index, note) in level3Notes.enumerated() {
                // Add some randomness to the position to avoid exact overlap
                let randomOffset = CGPoint(
                    x: CGFloat.random(in: -50...50),
                    y: CGFloat.random(in: -50...50)
                )
                let newPosition = CGPoint(
                    x: note.position.x + randomOffset.x,
                    y: note.position.y + randomOffset.y
                )
                
                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.1) {
                    levelManager.addDeathNote(
                        for: 4,
                        note: note.note,
                        position: newPosition,
                        rotation: note.rotation + Double.random(in: -15...15) 
                    )
                }
            }
            
            debugLog("Imported \(level3Notes.count) death notes from Level 3")
            debugLog("Starting Level 4 with \(startingDeathCount) total deaths")
        }
    }
    
    private func updatePhysics(in geometry: GeometryProxy) {
        if !isOnGround {
            playerVelocity.y += gravity
        }
        if isMovingLeft {
            playerPosition.x -= moveSpeed
        }
        if isMovingRight {
            playerPosition.x += moveSpeed
        }
        
        let newY = playerPosition.y + playerVelocity.y
        
        let platformTop = platform4Position.y - platform4Size.height / 2
        if newY >= platformTop - 35 { 
            playerPosition.y = platformTop - 35
            playerVelocity.y = 0
            isOnGround = true
        } else {
            playerPosition.y = newY
            isOnGround = false
        }
        
        // Check collision with coffee1.
        if !coffeeCollected[0] {
            let coffee1Frame = CGRect(
                x: coffee1Position.x - coffee1Size.width/2,
                y: coffee1Position.y - coffee1Size.height/2,
                width: coffee1Size.width,
                height: coffee1Size.height
            )
            let playerFrame = CGRect(
                x: playerPosition.x - 25,
                y: playerPosition.y - 35,
                width: 50,
                height: 70
            )
            if playerFrame.intersects(coffee1Frame) {
                coffeeCollected[0] = true
                swappedControls = true
                showSwappedMessage = true
                if (!hasBeenFooledBy.contains("coffee1")) {
                    timesFooled += 1
                    hasBeenFooledBy.insert("coffee1")
                    debugLog("Fooled by coffee1: Controls swapped!")
                }
                // Stop the player and wait for new input
                playerVelocity = .zero
                isMovingLeft = false
                isMovingRight = false
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    showSwappedMessage = false
                }
            }
        }

        // Check coffee collisions
        let playerBounds = CGRect(
            x: playerPosition.x - 25,
            y: playerPosition.y - 35,
            width: 50,
            height: 70
        )

        // Coffee2 collision (now collectible)
        if !coffeeCollected[1] {
            let coffee2Bounds = CGRect(
                x: coffee2Position.x - coffee2Size.width/2,
                y: coffee2Position.y - coffee2Size.height/2,
                width: coffee2Size.width,
                height: coffee2Size.height
            )
            if playerBounds.intersects(coffee2Bounds) {
                coffeeCollected[1] = true
                debugLog("Collected coffee2!")
            }
        }
        
        // Check bin collision
        let playerFrame = CGRect(
            x: playerPosition.x - 25,
            y: playerPosition.y - 35,
            width: 50,
            height: 70
        )
        
        let binFrame = CGRect(
            x: binPosition.x - binSize.width/2,
            y: binPosition.y - binSize.height/2,
            width: binSize.width,
            height: binSize.height
        )
        
        if playerFrame.intersects(binFrame) && showBin {
            showObstacles = false
            // Trigger dark mode and show glowing text with delay
            withAnimation(.easeInOut(duration: 1.0)) {
                isDarkMode = true
            }
            // Show glowing text after dark mode transition
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                withAnimation(.easeIn(duration: 0.5)) {
                    showGlowingText = true
                }
            }
        }
        
        // Only check obstacle collisions if they are visible
        if showObstacles {
            // Coffee3 collision check
            let coffee3Frame = CGRect(
                x: coffee3Position.x - coffee3Size.width/2,
                y: coffee3Position.y - coffee3Size.height/2,
                width: coffee3Size.width,
                height: coffee3Size.height
            )
            if playerFrame.intersects(coffee3Frame) {
                handleDeath(in: geometry)
                return
            }

            // Rejected1 collision check
            let rejected1Frame = CGRect(
                x: rejected1Position.x - rejected1Size.height/2, 
                y: rejected1Position.y - rejected1Size.width/2,
                width: rejected1Size.height,
                height: rejected1Size.width
            )
            if playerFrame.intersects(rejected1Frame) {
                handleDeath(in: geometry)
                return
            }

            // Rejected2 collision check
            let rejected2Frame = CGRect(
                x: rejected2Position.x - rejected2Size.height/2,
                y: rejected2Position.y - rejected2Size.width/2,
                width: rejected2Size.height,
                height: rejected2Size.width
            )
            if playerFrame.intersects(rejected2Frame) {
                handleDeath(in: geometry)
                return
            }

            // Rejected3 collision check
            let rejected3Frame = CGRect(
                x: rejected3Position.x - rejected3Size.width/2,
                y: rejected3Position.y - rejected3Size.height/2,
                width: rejected3Size.width,
                height: rejected3Size.height
            )
            if playerFrame.intersects(rejected3Frame) {
                if (!hasBeenFooledBy.contains("rejected3")) {
                    timesFooled += 1
                    hasBeenFooledBy.insert("rejected3")
                    debugLog("Fooled by rejected3!")
                }
            }
        }
        
        // Reset player if out of bounds
        if playerPosition.y > geometry.size.height + 100 {
            handleDeath(in: geometry)
        }
        
        // When player reaches x <= 200, trigger bin animation.
        if playerPosition.x <= 300 && homeVisible {
            homeVisible = false
            showBin = true
            // Animate bin upward from platform4 bottom to homePosition.
            withAnimation(Animation.easeOut(duration: 1.0)) {
                binPosition = homePosition
            }
        }
        
        // Check for glowing text collision
        if isDarkMode && showGlowingText {
            let textBounds = CGRect(
                x: glowingTextPosition.x - glowingTextSize.width/2,
                y: glowingTextPosition.y - glowingTextSize.height/2,
                width: glowingTextSize.width,
                height: glowingTextSize.height
            )
            
            let playerBounds = CGRect(
                x: playerPosition.x - 25,
                y: playerPosition.y - 35,
                width: 50,
                height: 70
            )
            
            if playerBounds.intersects(textBounds) {
                withAnimation(.easeInOut(duration: 0.5)) {
                    showBSOD = true
                }
            }
        }

        // Add invisible wall collision
        let invisibleWallRect = CGRect(
            x: invisibleWallConfig.position.x - invisibleWallConfig.size.width/2,
            y: invisibleWallConfig.position.y - invisibleWallConfig.size.height/2,
            width: invisibleWallConfig.size.width,
            height: invisibleWallConfig.size.height
        )
        
        if playerFrame.intersects(invisibleWallRect) {
            if isMovingRight {
                playerPosition.x = invisibleWallRect.minX - 25  // Stop player at wall's left edge
            }
        }
    }

    // Move these functions outside of updatePhysics
    private func updatePlayerState() {
        if isDead { return }
        
        // Check if player is in any hesitation zone
        let playerBounds = CGRect(
            x: playerPosition.x - 25,
            y: playerPosition.y - 35,
            width: 50,
            height: 70
        )
        
        let wasInZone = isInHesitationZone
        isInHesitationZone = hesitationZones.contains { zone in
            zone.intersects(playerBounds)
        }
        
        // Start timer when entering zone
        if !wasInZone && isInHesitationZone {
            hesitationStartTime = Date()
            debugLog("Entered hesitation zone")
        }
        
        // Check for hesitation only when in zone and not moving
        if isInHesitationZone && !isMovingLeft && !isMovingRight && isOnGround {
            if let startTime = hesitationStartTime {
                let currentTime = Date()
                let hesitationDuration = currentTime.timeIntervalSince(startTime)
                
                if hesitationDuration >= hesitationThreshold {
                    hesitationCount += 1
                    hesitationStartTime = currentTime  // Reset timer after counting hesitation
                    debugLog("Hesitation detected! Count: \(hesitationCount)")
                }
            }
        } else if !isInHesitationZone {
            hesitationStartTime = nil  // Reset timer when moving or outside zone
        }
        
        if !isOnGround {
            playerState = .jumping
        } else if isMovingLeft || isMovingRight {
            playerState = .walking
        } else {
            playerState = .idle
        }
    }

    private func updateAnimation() {
        if playerState == .walking {
            let now = Date()
            if now.timeIntervalSince(lastAnimationTime) >= animationInterval {
                walkFrame = (walkFrame % 4) + 1  // Assumes 4 running frames.
                lastAnimationTime = now
            }
        } else {
            walkFrame = 1
        }
    }

    private func updateRejected() {
        // Update rejected1
        if rejected1MovingUp {
            rejected1Position.y -= rejected1Speed
            if rejected1Position.y <= rejected1MaxTop {
                rejected1MovingUp = false
            }
        } else {
            rejected1Position.y += rejected1Speed
            if rejected1Position.y >= rejected1MaxBottom {
                rejected1MovingUp = true
            }
        }
        // Update rejected2
        if rejected2MovingUp {
            rejected2Position.y -= rejected2Speed
            if rejected2Position.y <= rejected2MaxTop {
                rejected2MovingUp = false
            }
        } else {
            rejected2Position.y += rejected2Speed
            if rejected2Position.y >= rejected2MaxBottom {
                rejected2MovingUp = true
            }
        }
        // Update rejected3
        if rejected3MovingUp {
            rejected3Position.y -= rejected3Speed
            if rejected3Position.y <= rejected3MaxTop {
                rejected3MovingUp = false
            }
        } else {
            rejected3Position.y += rejected3Speed
            if rejected3Position.y >= rejected3MaxBottom {
                rejected3MovingUp = true
            }
        }
    }

    private func resetPlayer() {
        playerPosition = CGPoint(x: 1100, y: 300) // Reset to starting position
        playerVelocity = .zero
        isOnGround = true
        isMovingLeft = false
        isMovingRight = false
        playerState = .idle
        playerFacingRight = false
        hasBeenFooledBy.removeAll()
        swappedControls = false // Reset swapped controls state too
    }

    private func addDeathNote(in geometry: GeometryProxy) {
        let notes = ["note1", "note2", "note3", "note4", "note5"]
        let noteIndex = deathCount % notes.count
        
        // Keep notes within visible area with padding
        let padding: CGFloat = 100
        let randomX = CGFloat.random(in: padding...(geometry.size.width - padding))
        let randomY = CGFloat.random(in: padding...(geometry.size.height - padding))
        let rotation = Double.random(in: -30...30)
        
        // Add note immediately without any conditions
        levelManager.addDeathNote(
            for: 4,
            note: notes[noteIndex],
            position: CGPoint(x: randomX, y: randomY),
            rotation: rotation
        )
        debugLog("Added death note at position: (\(randomX), \(randomY))")
    }

    // Update the handleDeath function to manage the death overlay timing and ensure death note appears
    private func handleDeath(in geometry: GeometryProxy) {
        if isDead { return }
        
        // First increment death count and add death note
        levelManager.incrementDeathCount(for: 4)
        currentLevelDeaths += 1
        addDeathNote(in: geometry)  // Add death note before showing overlay
        resetPlayer()
        
        // Then show death overlay
        isDead = true
        debugLog("Death in Level 4 - Total deaths across all levels: \(deathCount)")
        
        // Reset coffee collection states
        coffeeCollected = [false, false, false]
        
        // Clear death state after delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            isDead = false
        }
    }

    private func checkHomeCollision() {
        let playerBounds = CGRect(
            x: playerPosition.x - 25,
            y: playerPosition.y - 35,
            width: 50,
            height: 70
        )
        let homeBounds = CGRect(
            x: homePosition.x - homeSize.width/2,
            y: homePosition.y - homeSize.height/2,
            width: homeSize.width,
            height: homeSize.height
        )
        
        if playerBounds.intersects(homeBounds) {
            isLevelComplete = true
            isMovingLeft = false
            isMovingRight = false
            playerVelocity = .zero
            playerState = .idle
            
            // Calculate insights when reaching home
            totalTimeSpent = Date().timeIntervalSince(levelStartTime)
            
            predictionMessage = MLInsights.getPredictionMessage(
                level: 4,
                totalDeaths: deathCount,
                levelDeaths: currentLevelDeaths,
                hesitationCount: hesitationCount,
                timeSpent: totalTimeSpent,
                internalErrors: nil,
                timesFooled: timesFooled,
                playerTypeClassifier: typeClassifier,
                frustrationModel: frustrationModel
            )
        }
    }

    // Add the playerDied function to handle player death
    private func playerDied(in geometry: GeometryProxy) {
        isDead = true
        isMovingLeft = false
        isMovingRight = false
        playerVelocity = .zero
        
        // Add death note and increment death count
        currentLevelDeaths += 1
        levelManager.incrementDeathCount(for: 4)
        debugLog("Killed by rejected! Death count: \(currentLevelDeaths)")
        addDeathNote(in: geometry)
        
        // Handle player death animation and respawn
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            resetPlayer()
            isDead = false
        }
    }

    private func resetPosition() {
        // Reset coffee collection states
        coffeeCollected = [false, false, false]
    }
    
    // Add helper function for fade sequence
    private func advanceFadeSequence() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
            withAnimation(.easeInOut(duration: 1.0)) {
                showFadeText = false
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) { 
                if fadeTextIndex < fadeTexts.count - 1 {
                    fadeTextIndex += 1
                    withAnimation(.easeInOut(duration: 1.0)) {
                        showFadeText = true
                    }
                    advanceFadeSequence()
                } else {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        showRollingCredits = true
                    }
                }
            }
        }
    }

    private func playDeathSound() {
        guard let soundURL = Bundle.main.url(forResource: "windows_error", withExtension: "mp3") else {
            print("Error: Could not find sound file")
            return
        }
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: soundURL)
            audioPlayer?.play()
        } catch {
            print("Error playing sound: \(error.localizedDescription)")
        }
    }

    struct Level4_Previews: PreviewProvider {
        static var previews: some View {
            Level4()
                .environmentObject(LevelManager())
        }
    }
}
