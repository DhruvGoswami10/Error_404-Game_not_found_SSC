// Main Menu 

import SwiftUI
import AVFoundation

struct ContentView: View {
    @EnvironmentObject private var levelManager: LevelManager
    @State private var showQuitMessage = false
    @State private var startHovered = false
    @State private var optionsHovered = false
    @State private var quitHovered = false
    @State private var glitchOffset = CGSize.zero
    @State private var glitchScale = 1.0
    @State private var glitchOpacity = 1.0
    @State private var glitchRotation = 0.0
    
    // Timer to trigger glitch effect
    let timer = Timer.publish(every: 2.0, on: .main, in: .common).autoconnect()
    
    // Quit messages appear on clicking QUIT button
    private let quitMessages = [
        "Nah you for real?!",
        "You can't be serious",
        "Girl? ain't no way!",
        "Already giving up?",
        "That's kinda weak ngl",
        "Imagine quitting in a troll game. Couldn't be me.",
        "Oh, you thought this was optional?",
        "Go ahead. I'll just judge you silently.",
        "We both know you'll come back."
    ]
    
    var body: some View {
        Group {
            switch levelManager.currentState {
            case .mainMenu:
                MainMenuView()
            case .progressMap:
                ProgressMap()
            case .level(let level):
                LevelView(level: level)
            }
        }
    }
}

// Adding How to play sticky note at the start of the game
struct StickyNoteView: View {
    @Binding var isShowing: Bool
    
    private let noteContent = [
        "Error 404: Game Not Found",
        "A mildly frustrating experience",
        "",
        "🎮 Basic Controls:",
        "• ◀️▶️ Left/Right arrows to move",
        "• 🔼 Up arroww to jump",
        "• 👆 Tap the player for... something unpredictable",
        "• 📱 If idle, the player will start scrolling social media (typical)",
        "",
        "🌀 What to expect:",
        "• Nothing works as intended (and that's intentional)",
        "• Coffee might be your friend (or not)",
        "• Death counter is your only true companion",
        "• Some platforms are less trustworthy than others",
        "• Your choices will be analyzed by questionable ML models",
        "",
        "💡 Tips:",
        "• Hesitation will be noted",
        "• Death notes tell stories",
        "• When in doubt, it's probably a trap",
        "• The game remembers your mistakes",
        "",
        "⚠️ Warning:",
        "• Game may contain traces of trolling",
        "• Side effects include confusion and mild frustration",
        "• No players were harmed in the making of this game",
        "  (physically at least)",
        "",
        "🧠 Remember:",
        "📈 The best way to learn is to fail... a lot."
    ]
    
    var body: some View {
        ZStack {
            // Semi-transparent background
            Color.black.opacity(0.3)
                .ignoresSafeArea()
                .onTapGesture {
                    withAnimation {
                        isShowing = false
                    }
                }
            
            // Sticky note
            VStack {
                // Close button and header for sticky note
                HStack {
                    Text("How to Play")
                        .font(.system(size: 24, weight: .bold))
                        .padding(.leading)
                        .foregroundColor(.black)
                    Spacer()
                    Button(action: {
                        withAnimation {
                            isShowing = false
                        }
                    }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.title2)
                            .foregroundColor(.black.opacity(0.6))
                    }
                    .padding(.trailing)
                }
                .padding(.top)
                
                // Scrollable content
                ScrollView {
                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(noteContent, id: \.self) { line in
                            Text(line)
                                .font(.system(size: 16, weight: line.hasSuffix(":") ? .bold : .regular))
                                .foregroundColor(.black)  // Add this line to make text color black
                                .padding(.horizontal)
                        }
                    }
                    .padding(.vertical)
                }
            }
            .frame(width: 400, height: 500)
            .background(
                Color(red: 1.0, green: 0.95, blue: 0.7)  // Sticky note yellow
                    .shadow(color: .black.opacity(0.2), radius: 10, x: 5, y: 5)
            )
            .cornerRadius(15)
            .transition(.scale)
        }
    }
}

// Seperate view for main menu
struct MainMenuView: View {
    @EnvironmentObject private var levelManager: LevelManager
    @State private var showQuitMessage = false
    @State private var startHovered = false
    @State private var optionsHovered = false
    @State private var quitHovered = false
    @State private var glitchOffset = CGSize.zero
    @State private var glitchScale = 1.0
    @State private var glitchOpacity = 1.0
    @State private var glitchRotation = 0.0
    @State private var selectedQuitMessage = ""
    @State private var showHowToPlay = false
    @State private var audioPlayer: AVAudioPlayer?
    
    // Timer to trigger glitch effect
    let timer = Timer.publish(every: 2.0, on: .main, in: .common).autoconnect()
    
    private let quitMessages = [
        "Nah you for real?!",
        "You can't be serious",
        "Girl? ain't no way!",
        "Already giving up?",
        "That's kinda weak ngl",
        "Imagine quitting in a troll game. Couldn't be me.",
        "Oh, you thought this was optional?",
        "Go ahead. I'll just judge you silently.",
        "We both know you'll come back."
    ]
    
    
    private func playButtonSound() {
        guard let soundURL = Bundle.main.url(forResource: "Button_Click", withExtension: "mp3") else {
            print("Error: Could not find sound file")
            return
        }
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: soundURL)
            audioPlayer?.play()
        } catch {
            print("Error playing sound: \(error.localizedDescription)")
        }
    }
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Background
                Image("mainBackground")
                    .resizable()
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .scaledToFill()
                    .offset(x: 0, y: 0)
                    .clipped() 
                
                // 404 Logo with glitch effect
                ZStack {
                    Image("404 logo")
                        .resizable()
                        .frame(width: 300, height: 110)
                        .offset(y: -200) 
                        .offset(glitchOffset)
                        .scaleEffect(glitchScale)
                        .opacity(glitchOpacity)
                        .rotationEffect(.degrees(glitchRotation))
                        .onReceive(timer) { _ in
                            glitchEffect()
                        }
                }
                .zIndex(1)
                
                VStack(spacing: 20) {
                    // Start Button
                    Image("start")
                        .resizable()
                        .frame(width: 310, height: 50)
                        .scaleEffect(startHovered ? 1.1 : 1.0)
                        .onHover { isHovered in
                            startHovered = isHovered
                        }
                        .onTapGesture {
                            playButtonSound()
                            withAnimation(.easeInOut(duration: 0.3)) {
                                levelManager.currentState = .progressMap
                            }
                        }
                    
                    // How to play Button
                    Image("howToPlay")
                        .resizable()
                        .frame(width: 310, height: 50)
                        .scaleEffect(optionsHovered ? 1.1 : 1.0)
                        .onHover { isHovered in
                            optionsHovered = isHovered
                        }
                        .onTapGesture {
                            playButtonSound()
                            withAnimation {
                                showHowToPlay = true
                            }
                        }
                    
                    // Quit Button
                    Button(action: {
                        playButtonSound()
                        selectedQuitMessage = quitMessages.randomElement() ?? "Nah you for real?!"
                        withAnimation(.easeInOut(duration: 0.3)) {
                            showQuitMessage = true
                        }
                        // Auto-hide after 2 seconds
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            withAnimation(.easeInOut(duration: 0.3)) {
                                showQuitMessage = false
                            }
                        }
                    }) {
                        Image("quit")
                            .resizable()
                            .frame(width: 300, height: 60)
                            .offset(x: 0, y: 60)
                            .scaleEffect(quitHovered ? 1.1 : 1.0)
                    }
                    .buttonStyle(.plain)
                    .onHover { isHovered in
                        quitHovered = isHovered
                    }
                }
                .offset(y: 50)
                
                // Quit Messages
                if showQuitMessage {
                    Text(selectedQuitMessage)
                        .font(.system(size: 48, weight: .bold))
                        .foregroundColor(.red)
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 15)
                                .fill(Color.black.opacity(0.8))
                                .stroke(Color.red, lineWidth: 2)
                        )
                        .position(x: geometry.size.width / 2, 
                                y: geometry.size.height * 0.3)
                        .zIndex(2)
                        .transition(.opacity)
                }
                
                // Sticky note overlay
                if showHowToPlay {
                    StickyNoteView(isShowing: $showHowToPlay)
                        .zIndex(100)
                }
            }
        }
        .ignoresSafeArea()
        .onAppear {
            // Show how to play automatically on first launch
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                withAnimation {
                    showHowToPlay = true
                }
            }
        }
    }
    
    private func glitchEffect() {
        // Sequence of rapid glitch animations
        withAnimation(.linear(duration: 0.05)) {
            glitchOffset = CGSize(width: CGFloat.random(in: -10...10),
                                height: CGFloat.random(in: -10...10))
            glitchScale = Double.random(in: 0.95...1.05)
            glitchOpacity = Double.random(in: 0.8...1)
            glitchRotation = Double.random(in: -2...2)
        }
        
        // Reset after short delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            withAnimation(.linear(duration: 0.05)) {
                glitchOffset = .zero
                glitchScale = 1.0
                glitchOpacity = 1.0
                glitchRotation = 0
            }
        }
    }
}

#Preview {
    ContentView()
        .environmentObject(LevelManager())
}


