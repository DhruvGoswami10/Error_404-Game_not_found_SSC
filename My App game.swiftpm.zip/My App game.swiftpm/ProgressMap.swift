import SwiftUI
import AVFoundation

struct ProgressMap: View {
    @EnvironmentObject private var levelManager: LevelManager
    @State private var level1Hover = false
    @State private var level2Hover = false
    @State private var level3Hover = false
    @State private var level4Hover = false
    @State private var audioPlayer: AVAudioPlayer?
    
    private let progressConfig = (
        size: CGSize(width: 800, height: 100),  
        position: CGPoint(x: 585, y: 200),      
        scale: CGFloat(1.0),                    
        opacity: Double(0.8)                   
    )
    
    private let levelConfig = (
        level1: (
            size: CGSize(width: 100, height: 100),
            yOffset: CGFloat(50)    
        ),
        level2: (
            size: CGSize(width: 100, height: 100),
            yOffset: CGFloat(50)  
        ),
        level3: (
            size: CGSize(width: 100, height: 100),
            yOffset: CGFloat(50)   
        ),
        level4: (
            size: CGSize(width: 100, height: 100),
            yOffset: CGFloat(50)    
        )
    )
    
    private let tips = [
        "Press jump to jump. Revolutionary, I know.",
        "Falling is a valid speedrun strategy. Just not a good one.",
        "Spikes are there for decoration. Go ahead, test that theory.",
        "The best way to win is to not play. But here you are.",
        "Holding forward doesn't guarantee progress. Just suffering.",
        "If you think you found a secret path, you didn't.",
        "The platforms are fake. The checkpoints are fake. Your hope? Also fake.",
        "If something looks suspicious, it definitely is.",
        "There's no such thing as an 'easy level.' Only levels where you haven't died yet.",
        "Did you really just check if there's an invisible wall? Rookie mistake.",
        "Why do you keep trying to walk through spikes? It didn't work last time either.",
        "You're the only person who made it this far. Just kidding. You're #3287.",
        "Have you tried not dying? Might be worth a shot.",
        "Jumping off ledges randomly isn't a great strategy. But I respect the chaos.",
        "Yes, the platforms can disappear. No, I won't tell you which ones.",
        "There's probably a floor below you. But only one way to find out.",
        "If you're looking for hints… good luck.",
        "Every level has a way to win. Whether you find it? That's on you.",
        "No, you can't pay-to-win. But feel free to send donations.",
        "This game was made in 3 weeks but debugging took a lifetime.",
        "Originally, the 'energy drink' was coffee. But cans look cooler.",
        "At one point, there was a bug that made you fly. I almost kept it.",
        "The level transitions took longer to make than the actual levels.",
        "The ML Insights? 90% chaos, 10% logic.",
        "This game was almost called '404: Player Not Found.'"
    ]
    
    @State private var currentTip = ""
    @State private var showTip = false
    private let tipTimer = Timer.publish(every: 3, on: .main, in: .common).autoconnect()
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Background
                Image("background")
                    .resizable()
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .scaledToFill()
                
                // Progress
                Image("progress")
                    .resizable()
                    .frame(width: progressConfig.size.width, height: progressConfig.size.height)
                    .position(progressConfig.position)
                    .scaleEffect(progressConfig.scale)
                    .opacity(progressConfig.opacity)
                    .zIndex(1)  // Place between background and buttons
                
                HStack(spacing: geometry.size.width * 0.15) {
                    // Level 1
                    Button(action: {
                        playButtonSound()
                        withAnimation(.easeInOut(duration: 0.3)) {
                            levelManager.currentState = .level(1)
                        }
                    }) {
                        Image("level-1")
                            .resizable()
                            .frame(width: levelConfig.level1.size.width, height: levelConfig.level1.size.height)
                            .scaleEffect(level1Hover ? 1.1 : 1.0)
                            .opacity(levelManager.isLevelUnlocked(1) ? 1.0 : 0.5)
                            .offset(y: levelConfig.level1.yOffset)
                    }
                    .buttonStyle(.plain)
                    .onHover { hover in
                        withAnimation(.easeInOut(duration: 0.2)) {
                            level1Hover = hover
                        }
                    }
                    
                    // Level 2
                    Button(action: {
                        if levelManager.isLevelUnlocked(2) {
                            playButtonSound()
                            withAnimation(.easeInOut(duration: 0.3)) {
                                levelManager.currentState = .level(2)  
                            }
                        }
                    }) {
                        Image("level-2")
                            .resizable()
                            .frame(width: levelConfig.level2.size.width, height: levelConfig.level2.size.height)
                            .scaleEffect(level2Hover ? 1.1 : 1.0)
                            .opacity(levelManager.isLevelUnlocked(2) ? 1.0 : 0.5)
                            .offset(y: levelConfig.level2.yOffset)
                    }
                    .buttonStyle(.plain)
                    .onHover { hover in
                        withAnimation(.easeInOut(duration: 0.2)) {
                            level2Hover = hover
                        }
                    }
                    
                    // Level 3
                    Button(action: {
                        if levelManager.isLevelUnlocked(3) {
                            playButtonSound()
                            withAnimation(.easeInOut(duration: 0.3)) {
                                levelManager.currentState = .level(3)
                            }
                        }
                    }) {
                        Image("level-3")
                            .resizable()
                            .frame(width: levelConfig.level3.size.width, height: levelConfig.level3.size.height)
                            .scaleEffect(level3Hover ? 1.1 : 1.0)
                            .opacity(levelManager.isLevelUnlocked(3) ? 1.0 : 0.5)
                            .offset(y: levelConfig.level3.yOffset)
                    }
                    .buttonStyle(.plain)
                    .onHover { hover in
                        withAnimation(.easeInOut(duration: 0.2)) {
                            level3Hover = hover
                        }
                    }
                    
                    // Level 4 button
                    Button(action: {
                        if levelManager.isLevelUnlocked(4) {
                            playButtonSound()
                            withAnimation(.easeInOut(duration: 0.3)) {
                                levelManager.currentState = .level(4)
                            }
                        }
                    }) {
                        Image("level-4")
                            .resizable()
                            .frame(width: levelConfig.level4.size.width, height: levelConfig.level4.size.height)
                            .scaleEffect(level4Hover ? 1.1 : 1.0)
                            .opacity(levelManager.isLevelUnlocked(4) ? 1.0 : 0.5)
                            .offset(y: levelConfig.level4.yOffset)
                    }
                    .buttonStyle(.plain)
                    .onHover { hover in
                        withAnimation(.easeInOut(duration: 0.2)) {
                            level4Hover = hover
                        }
                    }
                }
                .position(x: geometry.size.width / 2, y: geometry.size.height / 2)
                
                VStack {
                    Spacer()
                    Text(currentTip)
                        .font(.system(size: 20, weight: .medium))
                        .foregroundColor(.white)
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .fill(Color.black.opacity(0.7))
                        )
                        .padding(.bottom, 30)
                        .opacity(showTip ? 1 : 0)
                        .animation(.easeInOut(duration: 0.5), value: showTip)
                }
                .zIndex(2)
                .onAppear {
                    updateTip()
                }
                .onReceive(tipTimer) { _ in
                    updateTip()
                }
            }
        }
        .ignoresSafeArea()
    }
    
    private func updateTip() {
        withAnimation {
            showTip = false
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            currentTip = tips.randomElement() ?? tips[0]
            withAnimation {
                showTip = true
            }
        }
    }
    
    private func playButtonSound() {
        guard let soundURL = Bundle.main.url(forResource: "Button_Click", withExtension: "mp3") else {
            print("Error: Could not find sound file")
            return
        }
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: soundURL)
            audioPlayer?.play()
        } catch {
            print("Error playing sound: \(error.localizedDescription)")
        }
    }
}

#Preview {
    ProgressMap()
        .environmentObject(LevelManager())
}
